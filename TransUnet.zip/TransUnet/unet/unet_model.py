""" Full assembly of the parts to form the complete network """

from .unet_parts import *
import torch



class TransUNet(nn.Module):
    def __init__(self, img_dim, in_channels, out_channels, head_num, mlp_dim, block_num, patch_dim, class_num):
        super().__init__()
        self.img_dim = img_dim
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.head_num = head_num
        self.mlp_dim = mlp_dim
        self.block_num = block_num
        self.patch_dim = patch_dim
        self.class_num = class_num

        self.encoder = DownSample(img_dim, in_channels, out_channels,
                               head_num, mlp_dim, block_num, patch_dim)

        self.decoder = UpSample(out_channels, class_num)

    def forward(self, x):
        x, x1, x2, x3 = self.encoder(x)
        x = self.decoder(x, x1, x2, x3)

        return x




#
# if __name__ == '__main__':
#     import torch
#
#     transunet = TransUNet(img_dim=256,
#                           in_channels=3,
#                           out_channels=256,
#                           head_num=8,
#                           mlp_dim=1024,
#                           block_num=8,
#                           patch_dim=16,
#                           class_num=13)
#
#     print(sum(p.numel() for p in transunet.parameters()))
#     print(transunet(torch.randn(1, 3, 256, 256)).shape)
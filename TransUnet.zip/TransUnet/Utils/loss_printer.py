import numpy as np
import torch
import os
from matplotlib import pyplot as plt


class loss_save():

    def __init__(self,train_loss):
        self.train_loss = train_loss

    def save_array(self):
        if os.path.exists('./loss_his/loss_his_VGGUnet.txt'):
            loss_array = torch.load('./loss_his/loss_his_VGGUnet.txt')
        else:
            loss_array = []

        loss_array.append(self.train_loss)

        torch.save(loss_array, './loss_his/loss_his_VGGUnet.txt')
        return loss_array

    # def save_acc(self):
    #     if os.path.exists('./loss_his/acc_his.txt'):
    #         acc_array = torch.load('./loss_his/acc_his.txt')
    #     else:
    #         acc_array = []
    #
    #     acc_array.append(self.acc)
    #     torch.save(acc_array, './loss_his/acc_his_VGGUnet.txt')
    #
    #     return acc_array
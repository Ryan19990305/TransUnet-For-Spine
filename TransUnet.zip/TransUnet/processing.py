import cv2
import numpy as np
from tqdm import tqdm
import os
from glob import glob


root_dir = '../groundtruth'
save_dir = './data/mask'


for img_path in glob(os.path.join(root_dir, '*.png')):
    img = cv2.imread(img_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    mask = np.zeros(img.shape, dtype=np.uint8)

    mask[img==38] = 2
    mask[img==75] = 1

    cv2.imwrite(os.path.join(save_dir, img_path.split('\\')[-1]), mask)


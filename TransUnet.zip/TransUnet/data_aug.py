import torch
import torchvision.transforms as tf
import cv2
import numpy as np
from PIL import Image

def data_aug(img, transform=None):
    if not transform is None:
        img = transform(Image.fromarray(img))
        img = np.array(img)

    return img


if __name__=='__main__':
    img_path = './data/train/imgs/0000.jpg'
    mask_path = './data/train/masks/0000.jpg'

    t = tf.Compose([
        # tf.RandomHorizontalFlip(p=0.5),
        tf.ColorJitter(brightness=0.5, contrast=0.2)
        # tf.ToTensor(),
    ])

    img = cv2.imread(img_path)
    mask = cv2.imread(mask_path)

    #augumentation
    img = data_aug(img, t)

    cv2.imshow('', img)
    cv2.imshow('mask', mask)
    cv2.waitKey(0)

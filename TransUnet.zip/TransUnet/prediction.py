import os
import cv2
import numpy as np
import torch
from PIL import Image
from unet import TransUNet
from tqdm import tqdm
import matplotlib.pyplot as plt
from glob import glob
import inference

if __name__ == '__main__':
    for index in range(1,9):
        img_dir = './dataset/dataset/valid_images/'+str(index)+'/'
        mask_dir = './dataset/dataset/valid_segment/'+str(index)+'/'
        save_dir = './predict_images/'+str(index)+'/'

        saver = inference.Infer()

        for file in tqdm(glob(os.path.join(img_dir, '*'))):
            # mask_path = mask_dir + file.split("\\")[1].replace('images', 'valid')
            img, pred = saver.predict(file)
            mask = cv2.imread(file.replace('valid_images', 'valid_segment').replace('images', 'valid'))
            print(mask.min(), mask.max())
            mask = np.uint8(mask * 20)
            vis = np.hstack([img, pred, mask])
            vis = cv2.resize(vis, (256 * 3, 256))
            cv2.imshow('img', vis)
            cv2.waitKey(10)

            cv2.imwrite(os.path.join(save_dir, file.split('\\')[-1].replace('_','').replace('images','')), pred)

